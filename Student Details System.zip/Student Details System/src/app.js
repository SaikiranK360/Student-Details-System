const express=require("express");
const mongoose=require("mongoose");
const path=require("path");
const app=express();
const port=process.env.PORT || 3000;

const template_path=path.join(__dirname,"../templates/views");
app.use(express.json());
app.use(express.urlencoded({extended:false}));

mongoose.connect("mongodb://localhost:27017/student",{
    useNewUrlParser:true,
    useUnifiedTopology:true,
    useCreateIndex:true
}).then(() =>{
    console.log(`connection successful`);
}).catch((err) =>{
    console.log(err);
});

const student_format=new mongoose.Schema({
    Name: {
        type:String,
        required:true
    },
    USN: {
        type:String,
        required:true,
        unique:true
    },
    Date_of_birth: {
        type:Date,
        required:true
    },
    Gender: {
        type: String,
        required:true
    },
    Phone_no: {
        type: Number,
        required:true,
        unique:true
    },
    email: {
        type: String,
        required: true,
        unique:true
    },
    Program: {
        type:String,
        required:true
    },
    Branch: {
        type:String,
        required:true
    },
    Semester: {
        type:Number,
        required:true
    },
    Password: {
        type: String,
        required: true
    }
});

const Student=new mongoose.model("Student",student_format);

const admin_format=new mongoose.Schema({
    Name: String,
    password: String
});

const Admin=new mongoose.model("Admin",admin_format);

app.set("view engine","hbs");
app.set("views",template_path);

app.get("/",(req,res) =>{
    res.render("index");
});

app.get("/index",(req,res) =>{
    res.render("index");
});

app.post("/register",async (req,res) =>{

    try{
        const new_student=new Student({
            Name: req.body.name,
            USN: req.body.usn,
            Date_of_birth: req.body.date,
            Gender: req.body.gender,
            Phone_no: req.body.phone,
            email: req.body.email,
            Program: req.body.program,
            Branch: req.body.branch,
            Semester: req.body.semester,
            Password:req.body.password
        });
        const registered=await new_student.save();
       
        res.render("index");
    }

    catch(err){
        res.send(err);
    }

});

app.get("/login",(req,res) =>{
    res.render("login");
});

app.post("/login",async (req,res) =>{
    try{
        const password=req.body.password;
        const datapass=await Student.find({USN: req.body.usn});
        
        if(password===datapass[0].Password){
            const data=await Student.findOne({USN: req.body.usn}).select({Password:0});
            res.send(data);
        }
        else{
            res.send("Invalid Credentials");
        }
       
    }
    catch(err){
        res.send(err);
    }
});

app.get("/adminlogin",(req,res) =>{
    res.render("adminlogin");
});

app.post("/adminlogin",async (req,res) =>{
    try{
        const P=await Admin.find({Name: req.body.name});
       
        const result=req.body.password;
      
        if(result===P[0].password)
        {
           
            res.render("register");
        }
        else{
            res.send("Invalid login credentials");
        }
    }
    catch(err){
        res.send("Invalid login credentials");
    }
});

app.get("/update",(req,res) =>{
    res.render("update");
});

app.post("/update",async (req,res) =>{
    try{
        const P=await Student.find({USN: req.body.usn});
       
        const result=req.body.password;
        const npassword=req.body.npassword;
        
        if(result===P[0].Password)
        {
           
            const updated=await Student.updateOne({USN: req.body.usn},{
                $set : {
                    Password: npassword
                }
            });

            res.render("login");
        }
        else{
            res.send("Invalid login credentials");
        }
    }
    catch(err){
        res.send("Invalid login credentials");
    }
});

app.get("/delete",(req,res) =>{
    res.render("delete");
});

app.post("/delete",async (req,res) =>{
    try{
        const deleted=await Student.deleteOne({USN: req.body.usn});
        res.render("adminlogin");
    }
    catch(err){
        res.send(err);
    }
});

app.listen(port,() =>{
    console.log(`server is running at port ${port}`);
});
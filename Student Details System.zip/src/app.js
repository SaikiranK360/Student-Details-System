const express=require("express");
const mongoose=require("mongoose");
const path=require("path");
const app=express();
const port=process.env.PORT || 3000;
const bcrypt=require("bcrypt");

const template_path=path.join(__dirname,"../templates/views");
app.use(express.json());
app.use(express.urlencoded({extended:false}));

mongoose.connect("mongodb://localhost:27017/student",{
    useNewUrlParser:true,
    useUnifiedTopology:true,
    useCreateIndex:true
}).then(() =>{
    console.log(`connection successful`);
}).catch((err) =>{
    console.log(err);
});

const student_format=new mongoose.Schema({
    Name: {
        type:String,
        required:true
    },
    USN: {
        type:String,
        required:true,
        unique:true
    },
    Date_of_birth: {
        type:Date,
        required:true
    },
    Gender: {
        type: String,
        required:true
    },
    Phone_no: {
        type: Number,
        required:true,
        unique:true
    },
    email: {
        type: String,
        required: true,
        unique:true
    },
    Program: {
        type:String,
        required:true
    },
    Branch: {
        type:String,
        required:true
    },
    Semester: {
        type:Number,
        required:true
    },
    Password: {
        type: String,
        required: true
    }
});

const Student=new mongoose.model("Student",student_format);

const admin_format=new mongoose.Schema({
    Name: String,
    password: String
});

const Admin=new mongoose.model("Admin",admin_format);

//admin@123

app.set("view engine","hbs");
app.set("views",template_path);

app.get("/",(req,res) =>{
    res.render("index");
});

app.get("/index",(req,res) =>{
    res.render("index");
});

app.post("/register",async (req,res) =>{

    try{
        
        const new_student=new Student({
            Name: req.body.name,
            USN: req.body.usn,
            Date_of_birth: req.body.date,
            Gender: req.body.gender,
            Phone_no: req.body.phone,
            email: req.body.email,
            Program: req.body.program,
            Branch: req.body.branch,
            Semester: req.body.semester,
            Password:await bcrypt.hash(req.body.password,10)
        });
        const registered=await new_student.save();
       
        res.render("index");
    }

    catch(err){

        res.send(`<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Login page</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        </head>
        <body>
            <h2 style="color:darkblue;margin-left:10px;margin-top:10px;">USN, Mobile no. and E-mail should be unique. Check whether you have entered any repeated values which are mentioned.</h2>
            <br /><br />
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
            <a href="/index" style="margin-left: 200px;"><button type="button" class="btn btn-primary" style="margin-top:20px;">Back</button></a>
        </body>
        </html>`);
    }

});

app.get("/login",(req,res) =>{
    res.render("login");
});

app.post("/login",async (req,res) =>{
    try{
        const password=req.body.password;
        const datapass=await Student.find({USN: req.body.usn});
        
        if(await bcrypt.compare(password,datapass[0].Password)){
            const data=await Student.findOne({USN: req.body.usn}).select({Password:0});

            //res.send(data);

            res.send(`<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Login page</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
            </head>
            <body>
            <div style="margin-left:350px;color:midnightblue;margin-top:100px;border:1px solid black;width:1000px;padding:15px;"><h2>Name : ${data.Name}</h2><h2>USN : ${data.USN}</h2><h2>Date of birth : ${data.Date_of_birth}</h2><h2>Gender : ${data.Gender}</h2>
            <h2>Phone no. : ${data.Phone_no}</h2><h2>E-mail : ${data.email}</h2><h2>Program : ${data.Program}</h2><h2>Branch : ${data.Branch}</h2><h2>Semester : ${data.Semester}</h2></div>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
            <a href="/index" style="margin-left: 1300px;"><button type="button" class="btn btn-primary" style="margin-top:20px;">Back</button></a>
            </body>
            </html>`);
        }
        else{
            res.send("Invalid Credentials");
        }
       
    }
    catch(err){
        res.send(err);
    }
});

app.get("/adminlogin",(req,res) =>{
    res.render("adminlogin");
});

app.post("/adminlogin",async (req,res) =>{
    try{
        const P=await Admin.find({Name: req.body.name});
       
        if(await bcrypt.compare(req.body.password,P[0].password))
        {
            res.render("register");
        }
        else{
            res.send("Invalid login credentials");
        }
    }
    catch(err){
        res.send("Invalid login credentials");
    }
});

app.get("/update",(req,res) =>{
    res.render("update");
});

app.post("/update",async (req,res) =>{
    try{
        const P=await Student.find({USN: req.body.usn});
       
        if(await bcrypt.compare(req.body.password,P[0].Password))
        {
           
            const updated=await Student.updateOne({USN: req.body.usn},{
                $set : {
                    Password: await bcrypt.hash(req.body.npassword,10)
                }
            });

            res.render("login");
        }
        else{
            res.send("Invalid login credentials");
        }
    }
    catch(err){
        res.send("Invalid login credentials");
    }
});

app.get("/delete",(req,res) =>{
    res.render("delete");
});

app.post("/delete",async (req,res) =>{
    try{
        const deleted=await Student.deleteOne({USN: req.body.usn});
        res.render("adminlogin");
    }
    catch(err){
        res.send(err);
    }
});

app.get("/search",(req,res) =>{
    res.render("search");
});

app.post("/search",async (req,res) =>{
    try{
        const data=await Student.findOne({USN: req.body.usn}).select({Password:0});

        res.send(`<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Login page</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        </head>
        <body>
        <div style="margin-left:350px;color:midnightblue;margin-top:100px;border:1px solid black;width:1000px;padding:15px;"><h2>Name : ${data.Name}</h2><h2>USN : ${data.USN}</h2><h2>Date of birth : ${data.Date_of_birth}</h2><h2>Gender : ${data.Gender}</h2>
        <h2>Phone no. : ${data.Phone_no}</h2><h2>E-mail : ${data.email}</h2><h2>Program : ${data.Program}</h2><h2>Branch : ${data.Branch}</h2><h2>Semester : ${data.Semester}</h2></div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
        <a href="/adminlogin" style="margin-left: 1300px;"><button type="button" class="btn btn-primary" style="margin-top:20px;">Back</button></a>
        </body>
        </html>`);
    }

    catch(err){
        res.send("<h1>Invalid credentials</h1>");
    }
})

app.listen(port,() =>{
    console.log(`server is running at port ${port}`);
});